<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('class__exam_schedules', function (Blueprint $table) {
            $table->id();
            $table->char('token',20)->unique()->collation('utf8_general_ci');
            $table->char('class_exam_token',20)
                ->collation('utf8_general_ci')
                ->comment('`class__exams`.`token`');
            $table->char('subject_token',20)
                ->collation('utf8_general_ci')
                ->comment('`subjects`.`token`');
            $table->tinyInteger('pass_mark');
            $table->tinyInteger('total_mark');
            $table->date('exam_date');
            $table->string('duration');
            $table->time('start_time');
            $table->time('end_time');
            $table->foreign('class_exam_token')
                ->references('token')
                ->on('class__exams');
            $table->foreign('subject_token')
                ->references('token')
                ->on('subjects');  
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('class__exam_schedules');
    }
};
