<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('annoncements', function (Blueprint $table) {
            $table->id();
            $table->char('token',20)->unique()->collation('utf8_general_ci');
            $table->char('class_token',20)
                ->collation('utf8_general_ci')
                ->comment('`classes`.`token`');
            $table->text('message');
            $table->tinyInteger('is_teacher');
            $table->tinyInteger('is_student');
            $table->tinyInteger('is_parent');
            $table->date('due_date');
            $table->foreign('class_token')
                ->references('token')
                ->on('classes');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('annoncements');
    }
};
