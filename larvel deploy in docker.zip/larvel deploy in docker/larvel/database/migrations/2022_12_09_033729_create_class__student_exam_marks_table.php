<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('class__student_exam_marks', function (Blueprint $table) {
            $table->id();
            $table->char('token',20)->unique()->collation('utf8_general_ci');
            $table->char('class_student_token',20)
                ->collation('utf8_general_ci')
                ->comment('`class__student`.`token`');
            $table->char('class_exam_schedule_token',20)
                ->collation('utf8_general_ci')
                ->comment('`class__exam_schedules`.`token`');
            $table->tinyInteger('gained_mark');
            $table->foreign('class_student_token')
                ->references('token')
                ->on('class__student');
            $table->foreign('class_exam_schedule_token')
                ->references('token')
                ->on('class__exam_schedules');  
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('class__student_exam_marks');
    }
};
