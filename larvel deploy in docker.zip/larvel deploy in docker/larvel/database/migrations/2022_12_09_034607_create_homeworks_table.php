<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('homeworks', function (Blueprint $table) {
            $table->id();
            $table->char('token',20)->unique()->collation('utf8_general_ci');
            $table->char('class_subject_teacher_token',20)
                ->collation('utf8_general_ci')
                ->comment('`class__subject_teacher`.`token`');
            $table->string('title');
            $table->text('description');
            $table->date('due_date');
            $table->tinyInteger('status');
            $table->foreign('class_subject_teacher_token')
                ->references('token')
                ->on('class__subject_teacher');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('homeworks');
    }
};
