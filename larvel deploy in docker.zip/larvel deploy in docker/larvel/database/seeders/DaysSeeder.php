<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class DaysSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('days')->delete();
        $days = [
            [
                'token' => "4536353231",
                'name' => "Monday",
                'created_at'=> gmdate("Y-m-d H:i:s"),
                'updated_at'=> gmdate("Y-m-d H:i:s")
            ],
            [
                'token' => "4536353232",
                'name' => "Tuesday",
                'created_at'=> gmdate("Y-m-d H:i:s"),
                'updated_at'=> gmdate("Y-m-d H:i:s")
            ],
            [
                'token' => "4536353233",
                'name' => "Wednesday",
                'created_at'=> gmdate("Y-m-d H:i:s"),
                'updated_at'=> gmdate("Y-m-d H:i:s")
            ],
            [
                'token' => "4536353234",
                'name' => "Thursday",
                'created_at'=> gmdate("Y-m-d H:i:s"),
                'updated_at'=> gmdate("Y-m-d H:i:s")
            ],
            [
                'token' => "4536353235",
                'name' => "Friday",
                'created_at'=> gmdate("Y-m-d H:i:s"),
                'updated_at'=> gmdate("Y-m-d H:i:s")
            ],
            [
                'token' => "4536353236",
                'name' => "Saturday",
                'created_at'=> gmdate("Y-m-d H:i:s"),
                'updated_at'=> gmdate("Y-m-d H:i:s")
            ],
            [
                'token' => "4536353237",
                'name' => "Sunday",
                'created_at'=> gmdate("Y-m-d H:i:s"),
                'updated_at'=> gmdate("Y-m-d H:i:s")
            ]
        ];
        DB::table('days')->insert(
            $days
        );
    }
}
