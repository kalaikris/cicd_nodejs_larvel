function view(){
	$('#school_config').toggleClass('hidden');
	$('#edit_class').toggleClass('hidden');
}
function set_time(){
	$('#school_config').toggleClass('hidden');
	$('#set_time').toggleClass('hidden');
}