<script>
    let teacherToken = localStorage.getItem("teacherToken");
    let teacherName = localStorage.getItem("teacherName");
    $(document).ready(function() {
        if(teacherToken == '' || teacherToken == undefined){
                window.location.href = "login";
            }
        $('#teachername').text(teacherName);
    })
    function logout() {
                $.ajax({
                    headers: {
                    Authorization: "Bearer " + teacherToken,
                    },
                    dataType: "JSON",
                    type: "POST",
                    url: "{{  url('api/teacher/logout') }}",
                }).done(function (data1) {
                    localStorage.removeItem('teacherToken');
                    window.location.href = "login";
                }).fail(function (httpObj, textStatus) {
                    if(httpObj.responseJSON.message == "Unauthenticated."){
                        swal({
                            title: httpObj.responseJSON.status,
                            text: httpObj.responseJSON.message,
                            icon: textStatus,
                        }).then(()=>{
                            localStorage.removeItem('teacherToken');
                            window.location.href = "login";
                        });
                    }else{
                        swal({
                            title: httpObj.responseJSON.status,
                            text: httpObj.responseJSON.message,
                            icon: textStatus,
                        });
                    }
                
                });
    }
</script>