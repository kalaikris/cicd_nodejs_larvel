<header class="nav_cont">
    <div class="sub_content">
        <img src="{{ asset('Teacher/asset/Rectangle@2x.png') }}">
        <div class="text_titel" id="community">
            <p>Welcome</p>
            <h4 id="teachername">Jerry Higgins ⌵</h4>
            <div class="community_box">
                <ul class="community_list">
                    <li style=""><a href="teacherprofile"><img src="{{ asset('Teacher/asset/teacher/teacher_profile.svg') }}"> My Profile</a></li>
                    <li><a onclick="logout()"><img src="{{ asset('Teacher/asset/logout.svg') }}"> Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</header>