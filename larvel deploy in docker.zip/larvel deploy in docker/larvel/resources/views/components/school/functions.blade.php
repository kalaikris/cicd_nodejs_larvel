<script>
// logout
$(document).ready(function() {
  if(bearerToken == '' || bearerToken == undefined){
          window.location.href = "login";
      }
})
function logout() {
  var request = $.ajax({
      type: "POST",
      url: "{{  url('api/school/logout') }}",
      headers: { 'Authorization': 'Bearer '+bearerToken},
      dataType : "json",
  });
  request.done(function(data) {
     localStorage.setItem("BearerTokenSchool","");
     window.location.href = "login";
  });
  request.fail(function(httpObj, textStatus) {
      swal({
          title: httpObj.responseJSON.status,
          text: httpObj.responseJSON.message,
          icon: textStatus,
          button: "OK",
      });
  });
}
</script>