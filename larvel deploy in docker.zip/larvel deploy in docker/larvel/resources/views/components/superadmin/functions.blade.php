<script>
    let superAdminToken = localStorage.getItem('superAdmintoken');
    let superAdminName = localStorage.getItem('superAdminName');
    $(document).ready(function() {
        if(superAdminToken == '' || superAdminToken == undefined){
                window.location.href = "login";
            }
            $('#adminname').text(superAdminName);
    })

    function logout() {
                $.ajax({
                    headers: {
                    Authorization: "Bearer " + superAdminToken,
                    },
                    dataType: "JSON",
                    type: "POST",
                    url: "{{  url('api/super-admin/logout') }}",
                }).done(function (data1) {
                    localStorage.removeItem('superAdminToken');
                    window.location.href = "login";
                }).fail(function (httpObj, textStatus) {
                    if(httpObj.responseJSON.message == "Unauthenticated."){
                        swal({
                            title: httpObj.responseJSON.status,
                            text: httpObj.responseJSON.message,
                            icon: textStatus,
                        }).then(()=>{
                            localStorage.removeItem('superAdminToken');
                            window.location.href = "login";
                        });
                    }else{
                        swal({
                            title: httpObj.responseJSON.status,
                            text: httpObj.responseJSON.message,
                            icon: textStatus,
                        });
                    }
                });
    }
</script>