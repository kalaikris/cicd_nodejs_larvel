<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('SuperAdmin.superAdminLogin');
});
Route::get('/login', function () {
    return view('SuperAdmin.superAdminLogin');
});
Route::get('/pass_recover', function () {
    return view('SuperAdmin.superAdminForgotPass');
});
Route::get('/superadmin_home', function () {
    return view('SuperAdmin.schoolOnboard');
});