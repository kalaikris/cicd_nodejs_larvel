<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Student extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $fillable = [
        'token',
        'school_token',
        'student_id',
        'password',
        'otp',
        'name',
        'gender',
        'date_of_birth',
        'blood_group',
        'emergency_contact_number',
        'mobile_number',
        'address',
        'is_rte',
        'is_admission',
        'status'
    ];
    protected $hidden = [
        'password'
    ];
}
