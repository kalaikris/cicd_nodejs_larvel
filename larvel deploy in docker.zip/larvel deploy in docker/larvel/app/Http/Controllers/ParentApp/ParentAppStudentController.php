<?php

namespace App\Http\Controllers\ParentApp;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Resources\ParentApp\ParentAppStudentResource;
use App\Http\Resources\ParentApp\ParentAppProfileResource;
use App\Http\Resources\ParentApp\ParentAppTeacherResource;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\ParentModel; 
use App\Models\StudentParent; 
use App\Models\ClassSubjectTeacher;
use App\Models\ClassStudent;
use App\Traits\HttpResponses;

class ParentAppStudentController extends Controller
{

    use HttpResponses;
    
    function studentDetail($ParentToken){
        $studentData = ParentAppProfileResource::collection(
            StudentParent::where("parent_token", $ParentToken)->get()
        );
        return $this->success(
            $studentData,
            "",
            200
        );
    }    

    function teacherDetail($StudentToken){
        $ClassData = ParentAppTeacherResource::collection(
            ClassStudent::where("student_token", $StudentToken)->get()
        );
        return $this->success(
            $ClassData,
            "",
            200
        );
    }
}
