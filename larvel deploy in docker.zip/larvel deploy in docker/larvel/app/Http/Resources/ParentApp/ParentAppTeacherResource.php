<?php

namespace App\Http\Resources\ParentApp;

use Illuminate\Http\Resources\Json\JsonResource;

class ParentAppTeacherResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'teacher_name' => $this->class->teacher->name,
            'subject'  => $this->subject->name
        ];
    }
}