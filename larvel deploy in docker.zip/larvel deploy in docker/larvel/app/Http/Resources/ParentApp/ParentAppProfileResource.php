<?php

namespace App\Http\Resources\ParentApp;

use Illuminate\Http\Resources\Json\JsonResource;

class ParentAppProfileResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'token'=>$this->student->token,
            'name' => $this->student->name,
            'student_id' => $this->student->student_id,
            'gender' => $this->student->gender,
            'date_of_birth' => $this->student->date_of_birth,
            'age' => $this->student->date_of_birth,
            'blood_group' => $this->student->blood_group,
            'mobile_number' => $this->student->mobile_number,
            'address' => $this->student->address,
            'father_name' => $this->student->father_name,
            'father_email_id' => $this->student->father_email_id,
            'father_mobile_number' => $this->student->father_mobile_number,
            'father_alter_number' => $this->student->father_alter_number,
            'mother_name' => $this->student->mother_name,
            'mother_email_id' => $this->student->mother_email_id,
            'mother_mobile_number' => $this->student->mother_mobile_number,
            'mother_alter_number' => $this->student->mother_alter_number
        ];
    }
}