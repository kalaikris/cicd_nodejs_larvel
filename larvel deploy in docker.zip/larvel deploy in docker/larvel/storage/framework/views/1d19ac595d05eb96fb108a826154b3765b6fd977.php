<script>
    let teacherToken = localStorage.getItem("teacherToken");
    let teacherName = localStorage.getItem("teacherName");
    $(document).ready(function() {
        if(teacherToken == '' || teacherToken == undefined){
                window.location.href = "login";
            }
        $('#teachername').text(teacherName);
    })
    function logout() {
                $.ajax({
                    headers: {
                    Authorization: "Bearer " + teacherToken,
                    },
                    dataType: "JSON",
                    type: "POST",
                    url: "<?php echo e(url('api/teacher/logout')); ?>",
                }).done(function (data1) {
                    console.log(data1);
                    localStorage.clear();
                    window.location.href = "login";
                    }).fail(function (httpObj, textStatus) {
                    console.log(httpObj);
                    console.log(textStatus);
                    swal({
                        title: httpObj.responseJSON.status,
                        text: httpObj.responseJSON.message,
                        icon: textStatus,
                    });
                    });
    }
</script><?php /**PATH /usr/share/nginx/html/hey-campus/resources/views/components/teacher/functions.blade.php ENDPATH**/ ?>