<header class="nav_cont">
    <div class="sub_content">
        <img src="<?php echo e(asset('School/asset/Rectangle@2x.png')); ?>">
        <div class="text_titel" id="community">
            <p>Welcome</p>
            <h4 id="user-name"></h4>
            <div class="community_box">
                <ul class="community_lists">
                        <li style=""><img src="<?php echo e(asset('School/asset/school profile.svg')); ?>"><a href="">School Profile</a></li>
                    <li style="border-bottom:unset;"><img src="<?php echo e(asset('School/asset/logout.svg')); ?>"><a href="#" onclick="logout()">Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</header><?php /**PATH /usr/share/nginx/html/hey-campus/resources/views/components/school/header.blade.php ENDPATH**/ ?>